package com.example.inventorymanager.ui.search;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.inventorymanager.MainActivity;
import com.example.inventorymanager.R;

import org.json.JSONException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

public class SearchFragment extends Fragment {
    public MainActivity MyMainActivity;
    JSONObject MyJson;
    JSONArray ListOfEntries;
    JSONObject FirstEntry;
    String FirstEntryName;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_search, container, false);
        TextView textView = root.findViewById(R.id.CardName);

        MyMainActivity = (MainActivity) getActivity();
        MyJson = (JSONObject) MyMainActivity.MyJSON;

        ListOfEntries = (JSONArray) MyJson.get("data");
        for (int i = 0; i < ListOfEntries.size(); i++) {
            FirstEntry = (JSONObject) ListOfEntries.get(i);
            FirstEntryName = (String) FirstEntry.get("Name");
        }

        textView.setText(FirstEntryName);
        return root;
    }
}